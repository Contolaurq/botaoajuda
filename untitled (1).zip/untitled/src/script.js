// Seleção de elementos do DOM através de IDs específicos
const modal = document.getElementById('ajudaModal');
const btnAbrir = document.getElementById('abrirModalBtn');
const btnFecharX = document.getElementById('fecharModalX');
const btnFecharBtn = document.getElementById('fecharModalBtn');

// Funções para gerenciar o estado de visibilidade
function abrirModal() {
    modal.style.display = 'block';
}

function fecharModal() {
    modal.style.display = 'none';
}

// Ouvintes de evento de clique
btnAbrir.addEventListener('click', abrirModal);
btnFecharX.addEventListener('click', fecharModal);
btnFecharBtn.addEventListener('click', fecharModal);

// Fecha o modal caso o clique ocorra na área escura (fora da janela)
window.addEventListener('click', function(event) {
    if (event.target === modal) {
        fecharModal();
    }
});